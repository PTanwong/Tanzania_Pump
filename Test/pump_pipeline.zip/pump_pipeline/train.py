"""
Train the pump status classifier and save it to disk.

Usage:
    python train.py

Outputs:
    models/pump_status_model.joblib   -- fitted sklearn Pipeline (bundles all preprocessing)
    Prints validation accuracy, F1, and a classification report to stdout.
"""

import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, f1_score

import config
import data_prep
from pipeline import build_pipeline

# Engineered features added by data_prep.engineer_features()
ENGINEERED_NUMERIC_COLS = ["recorded_year", "recorded_month", "pump_age"]


def main():
    print("Loading data...")
    df = data_prep.load_train_data()
    print(f"  {len(df):,} rows loaded")

    print("Engineering features...")
    X = data_prep.prepare_features(df, drop_target=True)
    y = df[config.TARGET_COL]

    numeric_cols = [c for c in config.NUMERIC_COLS + ENGINEERED_NUMERIC_COLS if c in X.columns]
    categorical_cols = [c for c in config.CATEGORICAL_COLS if c in X.columns]

    # id column shouldn't be a feature
    feature_cols = numeric_cols + categorical_cols
    X = X[feature_cols]

    print(f"  {len(numeric_cols)} numeric features, {len(categorical_cols)} categorical features")

    print("Splitting train/validation...")
    X_train, X_val, y_train, y_val = train_test_split(
        X, y,
        test_size=config.TEST_SIZE,
        random_state=config.RANDOM_STATE,
        stratify=y,
    )

    print("Building pipeline...")
    pipe = build_pipeline(
        numeric_cols=numeric_cols,
        categorical_cols=categorical_cols,
        high_cardinality_cols=config.HIGH_CARDINALITY_COLS,
    )

    print("Training model (this may take a minute)...")
    pipe.fit(X_train, y_train)

    print("\nEvaluating on holdout validation set...")
    y_pred = pipe.predict(X_val)
    acc = accuracy_score(y_val, y_pred)
    f1_macro = f1_score(y_val, y_pred, average="macro")
    print(f"  Accuracy: {acc:.4f}")
    print(f"  Macro F1: {f1_macro:.4f}")
    print("\nClassification report:")
    print(classification_report(y_val, y_pred))

    print("Refitting on full training data...")
    pipe.fit(X, y)

    config.MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({
        "pipeline": pipe,
        "feature_cols": feature_cols,
        "numeric_cols": numeric_cols,
        "categorical_cols": categorical_cols,
    }, config.MODEL_PATH)
    print(f"\nModel saved to {config.MODEL_PATH}")


if __name__ == "__main__":
    main()
