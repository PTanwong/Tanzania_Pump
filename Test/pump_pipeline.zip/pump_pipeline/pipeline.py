"""
Builds the sklearn Pipeline: rare-category bucketing -> imputation ->
encoding -> model. Bundling everything into one Pipeline object means the
saved model file is self-contained: no separate lookup tables to keep in
sync, no risk of preprocessing drift between train and inference.
"""

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier

import config


class RareCategoryBucketer(BaseEstimator, TransformerMixin):
    """
    For specified high-cardinality columns, replaces categories seen fewer
    than `min_frequency` times *in the training data* with 'other'.
    Learned frequencies are stored at fit time and reused at transform time,
    so this is safe to use on unseen test data without leakage.
    """

    def __init__(self, columns, min_frequency=20):
        self.columns = columns
        self.min_frequency = min_frequency

    def fit(self, X, y=None):
        self.keep_sets_ = {}
        for col in self.columns:
            counts = X[col].value_counts()
            self.keep_sets_[col] = set(counts[counts >= self.min_frequency].index)
        return self

    def transform(self, X):
        X = X.copy()
        for col in self.columns:
            keep = self.keep_sets_.get(col, set())
            X[col] = X[col].where(X[col].isin(keep), other="other")
        return X


def build_pipeline(numeric_cols, categorical_cols, high_cardinality_cols):
    """
    Assemble the full preprocessing + model pipeline.
    numeric_cols / categorical_cols: full feature lists after engineer_features()
    high_cardinality_cols: subset of categorical_cols to bucket rare values for
    """

    numeric_transformer = SimpleImputer(strategy="median")

    categorical_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="constant", fill_value="missing")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_transformer, numeric_cols),
        ("cat", categorical_transformer, categorical_cols),
    ])

    model = RandomForestClassifier(**config.RF_PARAMS)

    full_pipeline = Pipeline(steps=[
        ("bucket_rare", RareCategoryBucketer(
            columns=high_cardinality_cols,
            min_frequency=config.MIN_CATEGORY_FREQUENCY,
        )),
        ("preprocess", preprocessor),
        ("model", model),
    ])

    return full_pipeline
