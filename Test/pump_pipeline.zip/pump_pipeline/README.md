# Tanzania Water Pump — Status Prediction Pipeline

Predicts pump `status_group` (`functional` / `non functional` / `functional needs repair`)
from `train_values.csv` + `train_labels.csv`, and produces a submission for `test_values.csv`.

## Setup

```bash
pip install pandas scikit-learn joblib
```

Put the three source CSVs in `data/`:
- `data/train_values.csv`
- `data/train_labels.csv`
- `data/test_values.csv`

## Usage

```bash
python train.py     # trains model, prints validation metrics, saves models/pump_status_model.joblib
python predict.py    # loads saved model, writes outputs/submission.csv (id, status_group)
```

Current validation performance (80/20 holdout, Random Forest baseline):
- **Accuracy: 0.78**
- **Macro F1: 0.69** (the minority class `functional needs repair`, ~7% of data, is
  the hardest — precision 0.36 / recall 0.60. `class_weight="balanced_subsample"` is
  already applied to help with this, but it's the main lever left to pull.)

## How it's structured

| File | Purpose |
|---|---|
| `config.py` | All tunable settings: paths, dropped columns, feature lists, model hyperparameters. Change things here first. |
| `data_prep.py` | Loading + feature engineering (dates → year/month, pump age, cleaning known bad sentinel values like `0` in `gps_height`/`population`/`construction_year` and near-zero lon/lat). Stateless — safe to run on train or test independently. |
| `pipeline.py` | The sklearn `Pipeline`: rare-category bucketing → imputation → one-hot encoding → `RandomForestClassifier`. Everything is bundled into one fitted object, so `models/pump_status_model.joblib` is fully self-contained. |
| `train.py` | Runs the full training flow, evaluates on a holdout split, then refits on all training data before saving. |
| `predict.py` | Loads the saved model and scores `test_values.csv`. |

## Design decisions worth knowing about

- **Dropped columns** (`config.DROP_COLS`): `recorded_by` is constant; `wpt_name`,
  `subvillage`, `ward`, `scheme_name` are extremely high-cardinality free-text-like
  fields that add overfitting risk without a smarter encoding; `num_private` is
  >98% zero; several columns are near-duplicates of a sibling we kept
  (e.g. `quantity_group` vs `quantity`, `extraction_type` vs `extraction_type_class`).
- **Rare-category bucketing**: `funder`, `installer`, `lga` have thousands of
  unique values. Categories seen fewer than `MIN_CATEGORY_FREQUENCY` (default 20)
  times in training are bucketed to `"other"`, learned from training data only
  (no leakage) and stored inside the pipeline.
- **Sentinel-value cleaning**: several numeric columns use `0` to mean "unknown"
  rather than a real zero (`gps_height`, `population`, `construction_year`, and
  near-zero `longitude`/`latitude`). These are converted to `NaN` so the imputer
  handles them instead of skewing the distribution.
- **Class imbalance**: `functional needs repair` is only ~7% of labels. The model
  uses `class_weight="balanced_subsample"`; macro F1 is reported alongside accuracy
  so this minority class isn't hidden by the two larger classes.

## Extending this

- **Swap the model**: change `pipeline.py`'s `build_pipeline()` — the
  preprocessing (`ColumnTransformer`) is decoupled from the estimator, so
  dropping in `GradientBoostingClassifier`, `LightGBM`, or `XGBoost` only touches
  that one function.
- **Re-enable dropped high-cardinality columns**: `wpt_name`/`subvillage`/`ward`/
  `scheme_name` might carry signal with target encoding or hashing instead of
  one-hot — worth testing if the team wants to push accuracy further.
- **Hyperparameter tuning**: `config.RF_PARAMS` is the single place to adjust;
  wire in `GridSearchCV`/`RandomizedSearchCV` around `build_pipeline()` in
  `train.py` if you want a formal search rather than hand-tuned defaults.
