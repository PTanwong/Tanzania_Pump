"""
Data loading and feature engineering for the water pump pipeline.

Design principle: every transformation here is *stateless w.r.t. the raw CSVs*
(it derives new columns from existing ones) so it is safe to apply identically
to train and test data. Anything that must learn from training data only
(imputation values, category buckets, encodings) lives in the sklearn
Pipeline in `pipeline.py`, not here.
"""

import pandas as pd
import numpy as np

import config


def load_train_data():
    """Load and merge train_values.csv with train_labels.csv on id."""
    values = pd.read_csv(config.TRAIN_VALUES_PATH)
    labels = pd.read_csv(config.TRAIN_LABELS_PATH)
    df = values.merge(labels, on=config.ID_COL, how="inner")
    return df


def load_test_data():
    """Load test_values.csv (no labels)."""
    return pd.read_csv(config.TEST_VALUES_PATH)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add derived features and clean up known data quality issues.
    Safe to call on train or test data independently.
    """
    df = df.copy()

    # --- Date features ---
    df[config.DATE_COL] = pd.to_datetime(df[config.DATE_COL], errors="coerce")
    df["recorded_year"] = df[config.DATE_COL].dt.year
    df["recorded_month"] = df[config.DATE_COL].dt.month

    # --- Pump age at time of recording ---
    # construction_year has a lot of 0s (unknown) -> treat as missing, not "year 0"
    df["construction_year"] = df["construction_year"].replace(0, np.nan)
    df["pump_age"] = df["recorded_year"] - df["construction_year"]
    # Negative ages are data errors (recorded before construction) -> treat as missing
    df.loc[df["pump_age"] < 0, "pump_age"] = np.nan

    # --- gps_height of 0 is almost certainly missing (not sea level) given the
    # region spread; treat as NaN so the imputer handles it rather than skewing means ---
    df["gps_height"] = df["gps_height"].replace(0, np.nan)

    # --- longitude/latitude of ~0 are known bad sentinel values in this dataset ---
    df.loc[df["longitude"] < 1, "longitude"] = np.nan
    df.loc[df["latitude"] > -0.5, "latitude"] = np.nan

    # --- population of 0 -> unknown, not literally zero people served ---
    df["population"] = df["population"].replace(0, np.nan)

    # --- boolean columns come in as True/False/NaN mixed types, which breaks
    # OneHotEncoder (can't sort bool vs str). Cast to string, preserving NaN
    # as an actual missing value for the imputer to handle. ---
    for bool_col in ["public_meeting", "permit"]:
        if bool_col in df.columns:
            df[bool_col] = df[bool_col].map(
                {True: "true", False: "false"}
            ).where(df[bool_col].notna(), np.nan)

    # Drop the now-redundant raw date column and id (kept separately upstream)
    df = df.drop(columns=[config.DATE_COL])

    return df


def bucket_rare_categories(df: pd.DataFrame, ref_value_counts: dict) -> pd.DataFrame:
    """
    Replace rare categories with 'other' using frequency counts computed on
    TRAINING data only (passed in as ref_value_counts), so this can be applied
    identically to test data without leaking test-set category frequencies.
    """
    df = df.copy()
    for col, counts in ref_value_counts.items():
        if col not in df.columns:
            continue
        keep = {cat for cat, freq in counts.items() if freq >= config.MIN_CATEGORY_FREQUENCY}
        df[col] = df[col].where(df[col].isin(keep), other="other")
    return df


def compute_rare_category_reference(df: pd.DataFrame) -> dict:
    """Compute category frequency tables from TRAINING data for HIGH_CARDINALITY_COLS."""
    ref = {}
    for col in config.HIGH_CARDINALITY_COLS:
        ref[col] = df[col].value_counts().to_dict()
    return ref


def prepare_features(df: pd.DataFrame, drop_target: bool = False) -> pd.DataFrame:
    """
    Full feature prep applied identically to train/test:
    drop unused columns, engineer features. Rare-category bucketing and
    imputation happen inside the sklearn Pipeline (fit on train only).
    """
    df = df.copy()
    cols_to_drop = [c for c in config.DROP_COLS if c in df.columns]
    df = df.drop(columns=cols_to_drop)

    if drop_target and config.TARGET_COL in df.columns:
        df = df.drop(columns=[config.TARGET_COL])

    df = engineer_features(df)
    return df
