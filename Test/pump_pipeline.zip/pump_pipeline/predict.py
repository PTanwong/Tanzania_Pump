"""
Generate predictions on test_values.csv using the saved model.

Usage:
    python predict.py

Outputs:
    outputs/submission.csv  -- columns: id, status_group
"""

import joblib
import pandas as pd

import config
import data_prep


def main():
    print("Loading model...")
    bundle = joblib.load(config.MODEL_PATH)
    pipe = bundle["pipeline"]
    feature_cols = bundle["feature_cols"]

    print("Loading test data...")
    test_df = data_prep.load_test_data()
    ids = test_df[config.ID_COL]

    print("Engineering features...")
    X_test = data_prep.prepare_features(test_df, drop_target=False)
    X_test = X_test[feature_cols]

    print("Predicting...")
    preds = pipe.predict(X_test)

    submission = pd.DataFrame({
        config.ID_COL: ids,
        config.TARGET_COL: preds,
    })

    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    submission.to_csv(config.SUBMISSION_PATH, index=False)
    print(f"Predictions saved to {config.SUBMISSION_PATH}")
    print(f"\nPrediction distribution:\n{submission[config.TARGET_COL].value_counts()}")


if __name__ == "__main__":
    main()
