"""
Configuration for the water pump status prediction pipeline.
Central place to tweak columns, model params, and paths without touching pipeline logic.
"""

from pathlib import Path

# ---- Paths ----
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"
OUTPUT_DIR = BASE_DIR / "outputs"

TRAIN_VALUES_PATH = DATA_DIR / "train_values.csv"
TRAIN_LABELS_PATH = DATA_DIR / "train_labels.csv"
TEST_VALUES_PATH = DATA_DIR / "test_values.csv"

MODEL_PATH = MODEL_DIR / "pump_status_model.joblib"
SUBMISSION_PATH = OUTPUT_DIR / "submission.csv"

ID_COL = "id"
TARGET_COL = "status_group"

# ---- Columns dropped before modeling ----
# - recorded_by: constant, zero signal
# - wpt_name / subvillage / ward / scheme_name: extremely high cardinality free-text-like
#   IDs that mostly just add noise/overfitting risk for a first robust pipeline.
#   (Team can re-enable with target/hashing encoding later if they want to squeeze more signal.)
# - num_private: >98% zeros, near-constant
# - quantity_group / extraction_type_group / extraction_type / waterpoint_type_group / payment_type
#   / source_type: near-duplicates of a sibling column that we keep (kept the most granular
#   *stable* version of each group to avoid redundant/collinear categoricals).
DROP_COLS = [
    "recorded_by",
    "wpt_name",
    "subvillage",
    "ward",
    "scheme_name",
    "num_private",
    "quantity_group",
    "extraction_type",
    "extraction_type_group",
    "waterpoint_type_group",
    "payment_type",
    "source_type",
]

# ---- Date handling ----
DATE_COL = "date_recorded"

# ---- Numeric columns (kept as numeric features) ----
NUMERIC_COLS = [
    "amount_tsh",
    "gps_height",
    "longitude",
    "latitude",
    "population",
    "construction_year",
    "region_code",
    "district_code",
]

# ---- Categorical columns (one-hot encoded) ----
CATEGORICAL_COLS = [
    "funder",
    "installer",
    "basin",
    "region",
    "lga",
    "public_meeting",
    "scheme_management",
    "permit",
    "extraction_type_class",
    "management",
    "management_group",
    "payment",
    "water_quality",
    "quality_group",
    "quantity",
    "source",
    "source_class",
    "waterpoint_type",
]

# High-cardinality categoricals get frequency-limited (rare categories bucketed as "other")
# to keep one-hot encoding from exploding in width.
HIGH_CARDINALITY_COLS = ["funder", "installer", "lga"]
MIN_CATEGORY_FREQUENCY = 20  # categories seen fewer times than this get bucketed

# ---- Model ----
RANDOM_STATE = 42
TEST_SIZE = 0.2  # holdout split from train_values for validation

RF_PARAMS = {
    "n_estimators": 300,
    "max_depth": None,
    "min_samples_leaf": 2,
    "n_jobs": -1,
    "random_state": RANDOM_STATE,
    "class_weight": "balanced_subsample",
}
